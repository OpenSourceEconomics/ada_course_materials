from pathlib import Path

TEST_DATA = Path(__file__).parent.parent.parent.resolve().joinpath("tests", "data")
